---
name: PrepZen
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#ca8100'
  on-tertiary-container: '#3e2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies calm confidence, deep focus, and steady academic momentum for high schoolers navigating high-stakes examinations (Boards, JEE Main, NEET, CUET). High school students preparing for competitive exams often operate under intense cognitive load and anxiety. The visual direction intentionally avoids gamified sensory overload, patronizing mascots, and juvenile clip art in favor of an architectural, serene, and modern workspace.

The design movement synthesizes **Minimalism** and **Tactile Glassmorphism**:
- **Architectural Clarity:** Strict layout grids, generous negative space, and unambiguous visual hierarchies that reduce ambient stress and induce flow state.
- **Subtle Atmospheric Depth:** Dark-slate canvas layers punctuated by ambient backdrops, crisp 1px hairpins, and muted luminous glows that signify progress without visual noise.
- **Tactile Feedback:** Crisp micro-interactions, distinct card elevation changes on press/hover, and high-legibility typographic tokens engineered to make hours of problem-solving effortless.

## Colors

The palette balances deep focus with rewarding feedback mechanisms. 

- **Primary (`#6366F1` Indigo Focus):** Directs core actions, active states, progress timelines, and focal UI elements. It evokes cerebral depth and sustained attention.
- **Secondary (`#10B981` Emerald Mastery):** Dedicated to mastery metrics, solved questions, high-accuracy badges, and forward momentum.
- **Tertiary (`#F59E0B` Amber Essential):** Reserved for high-priority items, formula sheet highlights, revision flags, and the signature "⭐ MUST KNOW" badge.
- **Neutral (`#0F172A` Deep Obsidian / Slate):** Foundation surface color that prevents eye fatigue during late-night study marathons.

### Semantic Tiers
- **Backgrounds (Dark Mode):** Base canvas at `#0A0F1D`, elevated container surfaces at `#0F172A`, and top-level modals/sheets at `#1E293B`.
- **Text & Content Hierarchy:** High-emphasis text at `#F8FAFC`, mid-emphasis labels and hints at `#94A3B8`, and disabled/ghost boundaries at `#475569`.
- **Light Mode Transition:** When running in light mode, the base transitions to `#F8FAFC`, card containers shift to pure `#FFFFFF`, borders drop to `rgba(15, 23, 42, 0.08)`, and typography sets to `#0F172A` with secondary labels at `#64748B`.

## Typography

The typography pairs **Plus Jakarta Sans** for headlines and high-level milestones with **Inter** for dense test-prep prompts, scientific notation, and explanations. 

- **Display & Headlines:** Plus Jakarta Sans provides contemporary warmth and geometric poise. Its open letterforms keep chapter titles, countdown clocks, and performance milestones inviting.
- **Body & Numerical Data:** Inter delivers strict vertical metrics, high legibility across small math fractions, chemical formulas, and multi-paragraph practice question solutions.
- **Scale Adaptation:** Display sizes scale down by one step on mobile viewports to prevent line-wrapping of technical chapter titles (e.g., "Rotational Motion and Angular Momentum").

## Layout & Spacing

This design system uses a flexible grid model designed to accommodate varying cognitive contexts—from rapid-fire formula review on mobile to full-length timed mock tests on desktop:

- **Breakpoints:**
  - `Mobile (0 - 639px)`: 4 columns, `margin: 1rem`, `gutter: 1rem`. Bottom sheets, single-column study feeds, and sticky primary action bars.
  - `Tablet (640px - 1023px)`: 8 columns, `margin: 2rem`, `gutter: 1.25rem`. Split question navigator with dual-column cards.
  - `Desktop (1024px+)`: 12 columns, max container width of `1280px`, `margin: 3rem`, `gutter: 1.5rem`. Dedicated three-pane architecture: syllabus hierarchy (left), active workspace (center), and live progress/timer telemetry (right).
- **Rhythm Rules:** All layout heights, margins, and gaps adhere to a 4px/8px incremental cadence. Content blocks never crowd test questions; question prompts maintain at least `space-lg` separation from answer options.

## Elevation & Depth

Visual hierarchy is maintained through subtle, low-opacity borders paired with softly diffuse colored ambient glows rather than aggressive, muddy drop shadows.

- **Base Canvas (Level 0):** Hex `#0A0F1D`. Plain background with no shadow or border.
- **Subsurface Cards (Level 1):** Hex `#0F172A` with a 1px solid border of `rgba(255, 255, 255, 0.08)`. Shadow: `0 4px 16px -2px rgba(0, 0, 0, 0.35)`.
- **Raised Interactive Modules (Level 2 - Hover/Active):** Hex `#1E293B` with border `rgba(99, 102, 241, 0.3)`. Shadow: `0 8px 24px -4px rgba(99, 102, 241, 0.12), 0 4px 12px rgba(0, 0, 0, 0.4)`.
- **Modals, Floating Timer & Popovers (Level 3):** Hex `#1E293B` layered with backdrop blur (`blur(16px)`). Border `rgba(255, 255, 255, 0.14)`. Shadow: `0 20px 40px -8px rgba(0, 0, 0, 0.6)`.
- **Must-Know Accents:** When applied to crucial flashcards or highlighted syllabus items, containers gain a faint amber ring glow: `0 0 0 1px rgba(245, 158, 11, 0.4), 0 4px 20px -2px rgba(245, 158, 11, 0.12)`.

## Shapes

The design system implements a rounded geometry (`roundedness: 2`) that feels technical yet comfortable:

- **Base Radius (`0.5rem` / 8px):** Applied to form inputs, inline badges, math formula snippets, and code blocks.
- **Large Radius (`1rem` / 16px):** Applied to test question cards, subject module containers, and analytics widgets.
- **Extra Large Radius (`1.5rem` / 24px):** Dedicated to top-level exam modals, major stream selection cards (PCM/PCB), and bottom sheets.
- **Pill Radius (`9999px`):** Reserved exclusively for status indicators, "⭐ MUST KNOW" tags, subject filters, and segmented tab switchers.

## Components

### Buttons
- **Primary:** Solid `#6366F1` background, `#F8FAFC` text, `rounded-lg` (16px), medium weight typography. Pressed state applies a slight scale down (`scale(0.98)`).
- **Secondary / Ghost:** Transparent background with a 1px border of `rgba(255, 255, 255, 0.12)`. On hover, background fills to `rgba(99, 102, 241, 0.08)`.
- **Success / Submit:** `#10B981` solid background for "Submit Mock Test" or "Mark as Mastered".

### Chips & Badges
- **Pill Badges:** Fully rounded (`rounded-full`), height `28px`, horizontal padding `12px`.
- **⭐ MUST KNOW Badge:** Background `rgba(245, 158, 11, 0.12)`, border `rgba(245, 158, 11, 0.35)`, text `#F59E0B`, displaying a gold star icon with label-sm typography.
- **Subject Filter Chips:** Inactive chips have `#0F172A` fill and neutral border; active chips illuminate with `#6366F1` fill and high-contrast white text.

### Cards & Question Modules
- **MCQ Option Card:** 1px border `rgba(255, 255, 255, 0.08)`, background `#0F172A`, `rounded-lg` (16px). 
- **Selection States:** When chosen, card shifts border to `#6366F1`, background to `rgba(99, 102, 241, 0.1)`, and the selection radio icon animates to filled. Correct review state animates to `#10B981` border with subtle green glow.

### Checkboxes & Radio Buttons
- Crisp 20px inputs with 2px borders. Selected states feature clear check or solid dot indicators in primary indigo or success emerald, avoiding faint outlines.

### Input Fields
- Dark slate surface (`#0F172A`), `rounded-md` (8px), border `rgba(255, 255, 255, 0.12)`. Focus state introduces a crisp `#6366F1` glow ring without shifting surrounding element bounds.

### Exam Stream & Progress Module (Custom)
- Large interactive tiles (e.g., JEE Main vs. NEET switchers) with `rounded-xl` corners, icon indicators, and circular progress meters driven by the secondary emerald token to denote completed chapter weightage.